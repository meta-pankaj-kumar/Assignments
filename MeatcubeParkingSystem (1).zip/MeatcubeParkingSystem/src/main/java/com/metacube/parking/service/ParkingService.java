package com.metacube.parking.service;

import java.sql.SQLException;
import java.util.LinkedList;

import com.metacube.parking.dao.EmployeeDAO;
import com.metacube.parking.dao.ParkingDAO;
import com.metacube.parking.dao.PlanDAO;
import com.metacube.parking.dao.VehicleDAO;
import com.metacube.parking.model.Employee;
import com.metacube.parking.dto.dtoEmployee;
import com.metacube.parking.model.Plan;
import com.metacube.parking.model.Vehicle;

public class ParkingService {
	
	public boolean addEmployee(Employee employee) {
		
		EmployeeDAO db = new EmployeeDAO();
		try {
			db.insertEmployee(employee);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
	
	public boolean addVehicle(Vehicle vehicle , String email) {
		
		VehicleDAO db = new VehicleDAO();
		try {
			db.insertVehicle(vehicle, email);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
	
	public int getVehicleId(String email) {
		VehicleDAO db = new VehicleDAO();
		int vehicleId = 0;
		try {
			vehicleId = db.getVehicleId(email);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return vehicleId;
	}
	
	public boolean addPlan(Plan plan , String email , int i) {
		
		PlanDAO db = new PlanDAO();
		try {
			db.insertPlan(plan, email, i);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}

	public boolean checkAuthentication(String email, String password) {
		ParkingDAO db= new ParkingDAO();
		boolean flag = false;
		try {
			if(db.checkAuthentication(email, password)) {
				flag = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public dtoEmployee getUserProfile(String email) {
		try {
			return EmployeeDAO.getUserProfile(email);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public LinkedList<dtoEmployee> getFriendsProfile(String email) {
		try {
			return EmployeeDAO.getFriendsProfile(email);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public boolean updateEmployee(String email, dtoEmployee dtoemployee) {
		EmployeeDAO db = new EmployeeDAO();
		try {
			db.updateEmployee(email,dtoemployee);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
}