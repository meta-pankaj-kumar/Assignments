package com.metacube.parking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeatcubeParkingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeatcubeParkingSystemApplication.class, args);
	}

}
