package com.metacube.parking.Controller;

import java.util.LinkedList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.metacube.parking.dto.dtoEmployee;
import com.metacube.parking.model.Employee;
import com.metacube.parking.model.Login;
import com.metacube.parking.model.Plan;
import com.metacube.parking.model.Vehicle;
import com.metacube.parking.service.ParkingService;

@Controller
public class ParkingController {
	ParkingService service = new ParkingService();
	//This contain welcome message 
		@Value("${welcome.message}")
		private String welcomeMessage;

		/**
		 * This method redirect to index page
		 * @param model object of Model class
		 * @return String name of page
		 */
		@GetMapping("/index")
		public String goToIndexPage(Model model) {
			model.addAttribute("welcomeMessage",welcomeMessage);
			Employee employee = new Employee();
			model.addAttribute(employee);
			return "Registration";
			
		}
		
		@PostMapping("/addEmployee")
		public String addEmployee(@Valid @ModelAttribute("employee") Employee employee,BindingResult bindingResult,Model model,HttpSession session) {
			
			if(bindingResult.hasErrors()) {
				if(!employee.getPassword().equals(employee.getConfirmPassword())){
					ObjectError objectError = new ObjectError("Password","Password and Confirm Password should be same");
					bindingResult.addError(objectError);
				}
				return "Registration";	
			}
			else {
				service.addEmployee(employee);
				Vehicle vehicle = new Vehicle();
				model.addAttribute(vehicle);
				session.setAttribute("Email",employee.getEmail());
				return "Vehicle";
			}
		}
		
		@PostMapping("/addVehicle")
		public String addVehicle(@Valid @ModelAttribute("vehicle") Vehicle vehicle,BindingResult bindingResult,Model model,HttpSession session) {
			
			if(bindingResult.hasErrors()) {
				return "Vehicle";	
			}
			else {
				service.addVehicle(vehicle,(String)session.getAttribute("Email"));
				Plan plan = new Plan();
				model.addAttribute(plan);
				session.setAttribute("VehicleId",service.getVehicleId((String)session.getAttribute("Email")));
				session.setAttribute("Type",vehicle.getVehicleType());
				return "Plan";
			}
		}
		
		@PostMapping("/addPlan")
		public String addPlan(@Valid @ModelAttribute("plan") Plan plan,BindingResult bindingResult,Model model,HttpSession session , HttpServletRequest request) {
			
			if(bindingResult.hasErrors()) {
				return "xddz";	
			}
			else {
				plan.setCurrency(request.getParameter("CurrencySelect"));
				plan.setPrice(request.getParameter("TotalCost"));
				service.addPlan(plan, (String)session.getAttribute("Email"),(int) session.getAttribute("VehicleId"));
				Login login = new Login();
				model.addAttribute(login);
				return "Login";
			}
		}
		
		@GetMapping("/login")
		public String loginPage(Model model) {
			Login login = new Login();
			model.addAttribute(login);
			return "Login";
			
		}
		@PostMapping("/login")
		public String login(@Valid @ModelAttribute("login") Login login,BindingResult bindingResult,Model model,HttpSession session) {
			if(service.checkAuthentication(login.getEmail(),login.getPassword())) {
				session.setAttribute("Email",login.getEmail());
				session.setAttribute("UserProfile",service.getUserProfile((String)session.getAttribute("Email")));
				session.setAttribute("FriendsProfile",service.getFriendsProfile((String)session.getAttribute("Email")));
				return "Home";
			}
			return "Login";
		}
		
		@GetMapping("/friends")
		public String friends() {
			return "Friends";
		}
		
		@PostMapping("/profile")
		public String profile(HttpServletRequest req,HttpSession session) {
			String email = (String) req.getParameter("EmailId");
			System.out.println(email);
			if(((String)session.getAttribute("Email")).equals(email)) {
				session.setAttribute("Profile",session.getAttribute("UserProfile"));
				session.setAttribute("IsUser",true);
			}
			else {
				LinkedList<dtoEmployee> list = (LinkedList<dtoEmployee>)session.getAttribute("FriendsProfile");
				for(int index = 0 ; index < list.size() ; index ++) {
					if(list.get(index).getEmail().equals(email)) {
						System.out.println("Matched");
						session.setAttribute("Profile",list.get(index));
					}
				}
			}
			return "Profile";
		}
		
		@PostMapping("/update")
		public String update(Model model) {
			dtoEmployee dtoemployee = new dtoEmployee();
			model.addAttribute(dtoemployee);
			return "Update";
		}
		
		@PostMapping("/home")
		public String home(BindingResult bindingResult,Model model,HttpSession session) {
			session.setAttribute("UserProfile",service.getUserProfile((String)session.getAttribute("Email")));
			session.setAttribute("FriendsProfile",service.getFriendsProfile((String)session.getAttribute("Email")));
			return "Home";
		}
		
		@PostMapping("/detailsUpdate")
		public String detailsUpdate(@Valid @ModelAttribute("dtoemployee") dtoEmployee dtoemployee,BindingResult bindingResult,Model model,HttpSession session) {
			
			if(bindingResult.hasErrors()) {
				return "Update";	
			}
			else {
				service.updateEmployee((String)session.getAttribute("Email"),dtoemployee);
				session.setAttribute("UserProfile",service.getUserProfile((String)session.getAttribute("Email")));
				session.setAttribute("FriendsProfile",service.getFriendsProfile((String)session.getAttribute("Email")));
				return "Home";
			}
		}
}