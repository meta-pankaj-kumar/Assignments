package POJO;

public class Employee {
	private String name;
	private String gender;
	private String email;
	private String password;
	private String contact;
	private String company;
	public Employee( String name , String gender, String email , String password, String contact, String company) {
		this.name=name;
		this.contact=contact;
		this.email=email;
		this.gender=gender;
		this.password=password;
		this.company=company;
	}
	/**
	 * @return name of String Type
	 */
	public String getName() {
		return this.name;
	}
	/**
	 * @param name of String Type
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return company of String Type
	 */
	public String getCompany() {
		return this.company;
	}
	/**
	 * @param company of String Type
	 */
	public void setCompany(String company) {
		this.company = company;
	}
	/**
	 * @return gender of String Type
	 */
	public String getGender() {
		return this.gender;
	}
	/**
	 * @param gender of String Type
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return email of String Type
	 */
	public String getEmail() {
		return this.email;
	}
	/**
	 * @param email of String Type
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return password of String Type
	 */
	public String getPassword() {
		return this.password;
	}
	/**
	 * @param password of String Type
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return contact of String Type
	 */
	public String getContact() {
		return this.contact;
	}
	/**
	 * @param contact of String Type
	 */
	public void setContact(String contact) {
		this.contact = contact;
	}
	
}
