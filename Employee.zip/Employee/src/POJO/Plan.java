package POJO;

public class Plan {
	private int vehicleId;
	private String email;
	private String currency;
	private String planType;
	private String price;
	public Plan(int vehicleId , String email , String currency , String planType , String price) {
		this.vehicleId = vehicleId;
		this.price = price;
		this.planType = planType;
		this.email = email;
		this.currency = currency;
	}
	/**
	 * 
	 * @return vehicleId of String Type
	 */
	public int getVehicleId() {
		return vehicleId;
	}
	/**
	 * 
	 * @param vehicleId of String Type
	 */
	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}
	/**
	 * 
	 * @return email of String Type
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * 
	 * @param email of String Type
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * 
	 * @return currency of String Type
	 */
	public String getCurrency() {
		return currency;
	}
	/**
	 * 
	 * @param currency of String Type
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	/**
	 * 
	 * @return planType of String Type
	 */
	public String getPlanType() {
		return planType;
	}
	/**
	 * 
	 * @param planType of String Type
	 */
	public void setPlanType(String planType) {
		this.planType = planType;
	}
	/**
	 * 
	 * @return price of String Type
	 */
	public String getPrice() {
		return price;
	}
	/**
	 * 
	 * @param price of String Type
	 */
	public void setPrice(String price) {
		this.price = price;
	}
	
}
