
create database e_shopping_cart;
use e_shopping_cart;

CREATE TABLE user (
  Id int(11) NOT NULL AUTO_INCREMENT,
  Name varchar(255) NOT NULL,
  UserName varchar(25) UNIQUE NOT NULL,
  Gender varchar(6) NOT NULL check(Gender = 'Male' OR Gender = 'Female'),
  Email varchar(255) UNIQUE NOT NULL,
  Password varchar(15) NOT NULL,
  ContactNumber varchar(15) NOT NULL ,
  PRIMARY KEY (Id) ) ;

INSERT INTO user (Name , UserName , Gender , Email , Password , ContactNumber) 
Values ('Pankaj Kumar' , 'Pankaj' , 'Male' , 'pgpranjalgupta@gmail.com' , 1234 , 9044946450);

CREATE TABLE product (
ProductCode varchar(50) UNIQUE NOT NULL,
ProductName varchar(50) NOT NULL,
Type varchar(25) NOT NULL,
Price double NOT NULL,
PRIMARY KEY (ProductCode) );

INSERT INTO product (ProductCode , ProductName , Type , Price ) 
Values ('Laptop1' , 'AcerLaptop' , 'Laptop' , 40000.0);

INSERT INTO product (ProductCode , ProductName , Type , Price ) 
Values ('Laptop2' , 'AcerLaptop' , 'Laptop' , 45000.0);

INSERT INTO product (ProductCode , ProductName , Type , Price ) 
Values ('Laptop3' , 'DellLaptop' , 'Laptop' , 46000.0);

INSERT INTO product (ProductCode , ProductName , Type , Price ) 
Values ('Laptop4' , 'DellLaptop' , 'Laptop' , 43000.0);

INSERT INTO product (ProductCode , ProductName , Type , Price ) 
Values ('Shoe1' , 'Puma Shoe' , 'Shoe' , 4000.0);

INSERT INTO product (ProductCode , ProductName , Type , Price ) 
Values ('Shoe2' , 'Reebok Shoe' , 'Shoe' , 4200.0);

INSERT INTO product (ProductCode , ProductName , Type , Price ) 
Values ('Shoe3' , 'Relaxo Shoe' , 'Shoe' , 4900.0);

INSERT INTO product (ProductCode , ProductName , Type , Price ) 
Values ('Shoe4' , 'Bata Shoe' , 'Shoe' , 4070.0);

INSERT INTO product (ProductCode , ProductName , Type , Price ) 
Values ('Candy1' , 'Melody' , 'Toffee' , 2.0);

INSERT INTO product (ProductCode , ProductName , Type , Price ) 
Values ('Candy2' , 'Eclairs' , 'Toffee' , 3.0);

drop table orders;
drop table cart;

CREATE TABLE cart (
  ProductCode varchar(50) NOT NULL,
  Quantity int(50) NOT NULL,
  FOREIGN KEY (ProductCode) REFERENCES Product(ProductCode),
  PRIMARY KEY (ProductCode) ) ;